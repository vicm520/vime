import { TokenBank } from './components/TokenBank'

function App() {
  return (
    <TokenBank />
  )
}

export default App